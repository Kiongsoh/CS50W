from django.urls import path
from . import views

urlpatterns = [
    path('', views.restaurant_selection, name='restaurant_selection'),
    path('restaurant/<int:restaurant_id>/', views.menu_display, name='menu_display'),
    path('add-to-order/', views.add_to_order, name='add_to_order'),
    path('remove-from-order/', views.remove_from_order, name='remove_from_order'),
    path('cart/', views.view_cart, name='view_cart'),
    path('get-cart-quantity/', views.get_cart_quantity, name='get_cart_quantity'), # this route is used to get the total cart quantity in the navbar
    path('get-item-quantities/', views.get_item_quantities, name='get_item_quantities'),
    path('checkout/', views.checkout, name='checkout'),
    path('kitchen/', views.kitchen_orders, name='kitchen_orders'),
    path('kitchen/accept/<int:order_id>/', views.accept_order, name='accept_order'),

    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register, name='register'),
]