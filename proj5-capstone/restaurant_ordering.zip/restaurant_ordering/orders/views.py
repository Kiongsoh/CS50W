from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import HttpResponse, HttpResponseRedirect, render, redirect
from django.urls import reverse
from django.db import IntegrityError
from .models import Restaurant, MenuItem, Order, OrderItem, User

from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_protect
import traceback
import json

# i think currently the status are not tagged correctly.
# for example, when customer order, the status is 'accepted' but not 'pending'

def restaurant_selection(request):
    # Fetch all restaurants from the database
    restaurants = Restaurant.objects.all()
    # Render the restaurant selection page with the list of restaurants
    return render(request, 'orders/restaurant_selection.html', {'restaurants': restaurants})

def menu_display(request, restaurant_id):
    # Get the specific restaurant based on the restaurant_id
    restaurant = Restaurant.objects.get(id=restaurant_id)
    # Fetch all menu items for this restaurant
    menu_items = MenuItem.objects.filter(restaurant=restaurant)
    # Render the menu selection page with restaurant and menu items
    return render(request, 'orders/menu_display.html', {'restaurant': restaurant, 'menu_items': menu_items})

@login_required #This decorator ensures that only authenticated users can access the view
@require_POST #This decorator restricts the view to only accept POST requests - POST is used for creating or updating resources
@csrf_protect #This decorator is used to protect the view against Cross-Site Request Forgery (CSRF) attacks - it is used to verify that the request originates from your site and not from a third party
def add_to_order(request):
    # 1. Parse the JSON data from the request body
    # 2. Check if item_id is provided
    # 3. Get the MenuItem object
    # 4. Get or create an Order for the current user with 'incart' status
    # 5. Get or create an OrderItem for this menu item in the order
    # 6. If the OrderItem already existed, increment its quantity
    # 7. Update the total price of the order
    # 8. Return a success response  

    # Parse the JSON data from the request body
    data = json.loads(request.body)
    item_id = data.get('item_id')

    # Check if item_id is provided
    if not item_id:
        return JsonResponse({'success': False, 'error': 'Item ID is required'}, status=400)
    
    try:
        # Get the MenuItem object
        menu_item = MenuItem.objects.get(id=item_id)                

        # get_or_create is used to get an existing order or create a new one if it doesn't exist
        # Get or create an Order for the current user with 'incart' status
        # it will return a Tuple of order object and a boolean value
        # <Order: Order object (1)>
        # True if a new object was created, or False if an existing object was retrieved.
        order, created = Order.objects.get_or_create(
            customer=request.user,
            status='incart',
            defaults={'restaurant': menu_item.restaurant, 'total_price': 0}
        )

        # Get or create OrderItem for this menu item in the order
        order_item, created = OrderItem.objects.get_or_create(
            order=order,
            menu_item=menu_item,
            defaults={'quantity': 1}
        )

        # If the OrderItem already existed, increment its quantity
        if not created:
            order_item.quantity += 1
            order_item.save()

        # Update the total price of the order
        order.total_price += menu_item.price
        order.save()

        # Return a success response
        return JsonResponse({'success': True})

    except MenuItem.DoesNotExist:
        # Handle the case where the menu item doesn't exist
        return JsonResponse({'success': False, 'error': 'Menu item not found'}, status=404)
    except Exception as e:
        # Handle any other exceptions that might occur
        # more detailed error logging
        print(f"Error in add_to_order: {str(e)}")
        print(traceback.format_exc())
        return JsonResponse({'success': False, 'error': str(e)}, status=500)

# ---------------------------------------------------------------------------------------

@login_required #This decorator ensures that only authenticated users can access the view
@require_POST #This decorator restricts the view to only accept POST requests - POST is used for creating or updating resources
@csrf_protect #This decorator is used to protect the view against Cross-Site Request Forgery (CSRF) attacks - it is used to verify that the request originates from your site and not from a third party
def remove_from_order(request):
    # Parse the JSON data from the request body
    data = json.loads(request.body)
    item_id = data.get('item_id')

    # Check if item_id is provided
    if not item_id:
        return JsonResponse({'success': False, 'error': 'Item ID is required'}, status=400)
    
    try:
        # Get the MenuItem object
        menu_item = MenuItem.objects.get(id=item_id)                

        # Get an Order for the current user with 'incart' status
        order = Order.objects.get(customer=request.user, status='incart')

        # Get or create an OrderItem for this menu item in the order
        order_item = OrderItem.objects.get(order=order, menu_item=menu_item)
        
        if order_item.quantity > 1:
            order_item.quantity -= 1
            order_item.save()
        else:
            order_item.delete()
        
        # Update the total price of the order
        order.total_price -= menu_item.price
        order.save()

        # Return a success response
        return JsonResponse({'success': True})

    except (MenuItem.DoesNotExist, Order.DoesNotExist, OrderItem.DoesNotExist):
        # Handle the case where the menu item doesn't exist
        return JsonResponse({'success': False, 'error': 'Item not found in order'}, status=404)
    
    except Exception as e:
        # Handle any other exceptions that might occur
        # more detailed error logging
        print(f"Error in add_to_order: {str(e)}")
        print(traceback.format_exc())
        return JsonResponse({'success': False, 'error': str(e)}, status=500)

# ---------------------------------------------------------------------------------------
@login_required
@csrf_protect
# this function is used to get the total cart quantity in the navbar
def get_cart_quantity(request):
    print("get_cart_quantity view called")  # Add this line
    try:
        order = Order.objects.get(customer=request.user, status='incart')
        # orderitem_set: This is automatically created by Django for reverse relations.
        # It's named after the model (OrderItem) in lowercase, followed by _set.
        # .all(): This method retrieves all related OrderItem objects for the given Order.
        # sum(): This function calculates the total sum of the quantity field for all OrderItem objects in the queryset.
        quantity = sum(item.quantity for item in order.orderitem_set.all())
        print(quantity)
    except Order.DoesNotExist:
        quantity = 0
    return JsonResponse({
        'quantity': quantity,
        'total_price': order.total_price
        })
# ---------------------------------------------------------------------------------------
@login_required
@csrf_protect #This decorator is used to protect the view against Cross-Site Request Forgery (CSRF) attacks - it is used to verify that the request originates from your site and not from a third party
def get_item_quantities(request):
    try:
        # Get the current user's cart
        order = Order.objects.get(customer=request.user, status='incart')
        
        # Create a dictionary of item_id: quantity pairs
        # .all(): This method retrieves all related OrderItem objects for the given Order.
        quantities = {
            item.menu_item.id: item.quantity 
            for item in order.orderitem_set.all()
        }

        total_prices = {
            item.menu_item.id: item.total_price 
            for item in order.orderitem_set.all()
        }
        
        # print(f"Retrieved quantities: {quantities}")  # Debug print
        print(f"Retrieved prices: {total_prices}")  # Debug print
        return JsonResponse({
            'success': True,
            'quantities': quantities,
            'total_prices': total_prices})
        
    except Order.DoesNotExist:
        # If no order exists, return empty quantities
        return JsonResponse({'success': True, 'quantities': {}})
    except Exception as e:
        print(f"Error in get_item_quantities: {str(e)}")
        return JsonResponse({'success': False, 'error': str(e)}, status=500)

# ---------------------------------------------------------------------------------------
@login_required
def view_cart(request):
    try:
        # Try to get the pending order for the current user
        order = Order.objects.get(customer=request.user, status='incart')
    except Order.DoesNotExist:
        # If no pending order exists, set order to None
        order = None
    # Render the cart page with the current order (if it exists)
    return render(request, 'orders/cart.html', {'order': order})

@login_required
def checkout(request):
    if request.method == 'POST':
        # Get the pending order for the current user
        order = Order.objects.get(customer=request.user, status='pending')
        # Change the order status to 'accepted'
        order.status = 'accepted'
        order.save()
        # Redirect to the order confirmation page
        return redirect('order_confirmation')
    # If it's a GET request, just render the checkout page
    return render(request, 'orders/checkout.html')

@login_required
def kitchen_orders(request):
    # Check if the user is kitchen staff
    if not request.user.is_kitchen:
        # If not, redirect them to the restaurant selection page
        return redirect('restaurant_selection')
    # Get all orders with 'accepted' status
    orders = Order.objects.filter(status='accepted')
    # Render the kitchen orders page with the list of accepted orders
    return render(request, 'orders/kitchen_orders.html', {'orders': orders})

@login_required
def accept_order(request, order_id):
    # Check if the user is kitchen staff
    if not request.user.is_kitchen:
        # If not, redirect them to the restaurant selection page
        return redirect('restaurant_selection')
    # Get the specific order based on the order_id
    order = Order.objects.get(id=order_id)
    # Change the order status to 'completed'
    order.status = 'completed'
    order.save()
    # Redirect back to the kitchen orders page
    return redirect('kitchen_orders')

def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        email = request.POST["email"]
        password = request.POST["password"]
        user = authenticate(request, username=email, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("restaurant_selection"))
        else:
            return render(request, "orders/login.html", {
                "message": "Invalid email and/or password."
            })
    else:
        return render(request, "orders/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("restaurant_selection"))


def register(request):
    if request.method == "POST":
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "orders/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(email, email, password)
            user.save()
        except IntegrityError as e:
            print(e)
            return render(request, "orders/register.html", {
                "message": "Email address already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("restaurant_selection"))
    else:
        return render(request, "orders/register.html")